<?php
/*
 * Use this class to render objects or array elements..
 */
class rander {

    public function __construct() {
        
    }

}

?>
Current stable version : 1.4
<h2>Download from Github</h2>
If you're familiar with GIT run this command to copy the template into your directory
<pre>
    https://github.com/Azenis/Template.git
</pre>
<h2>Manual download</h2>
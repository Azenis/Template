Allan Rehhoff Template
===
Just upload the files to your server and you're ready to go :)

Download: git clone https://github.com/Azenis/Template.git

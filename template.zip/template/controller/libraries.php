<?php $template->add("jqueryui"); ?>
<?php $template->message("You can add third party libraries such as jqueryui", "ui-state-highlight ui-corner-all"); ?>
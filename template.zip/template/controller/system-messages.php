<?php $template->message("Class: success - Use this type of message to tell user something went right", "success"); ?>
<?php $template->message("Class: attention - This message means there is a thing to which the user should make a decision", "attention"); ?>
<?php $template->message("Class: error - If something went wrong you should use this type", "error"); ?>
<?php $template->message("Class: info - This type is just to provide feedback to the user ", "info"); ?>
<?php
//user roles
define("ADMIN", 1);
define("USER", 2);
define("GUEST", 3);
//let's the application run - DO NOT REMOVE
define("APPLICATION_RUNNING", TRUE);
?>